!chmod 755 cml/setup-env.sh
!cml/setup-env.sh